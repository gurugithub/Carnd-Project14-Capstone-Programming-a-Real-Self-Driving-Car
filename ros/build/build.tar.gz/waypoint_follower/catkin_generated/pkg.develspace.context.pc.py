# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/student/catkin_ws/CarND-Capstone/ros/src/waypoint_follower/include".split(';') if "/home/student/catkin_ws/CarND-Capstone/ros/src/waypoint_follower/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;std_msgs;tf;geometry_msgs;styx_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-llibwaypoint_follower".split(';') if "-llibwaypoint_follower" != "" else []
PROJECT_NAME = "waypoint_follower"
PROJECT_SPACE_DIR = "/home/student/catkin_ws/CarND-Capstone/ros/devel"
PROJECT_VERSION = "0.0.0"
