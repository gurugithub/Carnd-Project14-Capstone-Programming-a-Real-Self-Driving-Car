# generated from catkin/cmake/template/order_packages.context.py.in
source_root_dir = "/home/student/catkin_ws/CarND-Capstone/ros/src"
whitelisted_packages = "".split(';') if "" != "" else []
blacklisted_packages = "".split(';') if "" != "" else []
underlay_workspaces = "/home/student/catkin_ws/CarND-Capstone/ros/devel;/opt/ros/kinetic".split(';') if "/home/student/catkin_ws/CarND-Capstone/ros/devel;/opt/ros/kinetic" != "" else []
